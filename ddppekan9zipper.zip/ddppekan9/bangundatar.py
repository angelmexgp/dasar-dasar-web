def persegi (sisi):
    luas = sisi*sisi
    print("luas persegi dengan sisi",sisi,"adalah",luas)
def segitiga (alas, tinggi):
    luas = alas*tinggi
    print("luas segitiga dengan alas",alas,"dan tinggi",tinggi,"adalah",luas)
def persegiPanjang (panjang, lebar):
    luas = panjang*lebar
    print("luas persegi panjang dengan panjang",panjang,"dan lebar",lebar,"adalah",luas)
def lingkaran (r):
    phi = 3.14
    luas = phi*r**2
    print("luas lingkaran dengan jari-jari",r,"adalah",luas)
def jajarGenjang (alas, tinggi):
    luas = alas*tinggi
    print("luas jajar genjang dengan alas",alas,"dan tinggi",tinggi,"adalah",luas)