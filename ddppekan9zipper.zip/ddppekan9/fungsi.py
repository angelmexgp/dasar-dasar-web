import math

from bangunruang import kubus
kubus (6)
print 

from bangundatar import segitiga
segitiga (6,8)
print

from opratorhitung import tambah
tambah (6, 3)
print 